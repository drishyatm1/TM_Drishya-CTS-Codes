package com.cts;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

@RestController
public class SecurityController {
	
		
		@RequestMapping(value ="/admin/{name}/{password}",method = RequestMethod.GET,produces = "application/json")
	    public String visitAdminPage() {
	        return "\"My login is success\"" ;
	    }
		
		
	    }
	 
	
	    
	    
	


