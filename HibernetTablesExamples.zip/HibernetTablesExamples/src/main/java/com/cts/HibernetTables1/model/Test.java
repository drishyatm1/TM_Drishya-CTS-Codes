package com.cts.HibernetTables1.model;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.cfg.Configuration;

public class Test {
	public static void main(String[] args) {
		Configuration configuration=new Configuration().configure();
    	SessionFactory sf=configuration.buildSessionFactory();
    	Session session=sf.openSession();
       	session.beginTransaction();
       	Common cc1=new Common(101,"Athreya");
    	Common cc2=new Common(102,"Athre");
    	Common cc3=new Common(103,"Athr");
    	session.save(cc1);
    	session.save(cc2);
    	session.save(cc3);
    	Customer cst1=new Customer("tv","DebitCard");
    	Customer cst2=new Customer("tv","DebitCard");
    	Customer cst3=new Customer("tv","DebitCard");
    	session.save(cst1);
    	session.save(cst2);
    	session.save(cst3);
    	session.getTransaction().commit();
    	session.close();
	}

}
