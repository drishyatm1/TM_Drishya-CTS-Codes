package com.cts.HibernetTables1.model;

import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Inheritance;
import javax.persistence.InheritanceType;

@Entity
@Inheritance(strategy =InheritanceType.TABLE_PER_CLASS)
public class Common {
	@Id
private int id;
private String name;

	public Common() {
		System.out.println("Object is created");
		
	}

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public Common(int id, String name) {
		
		this.id = id;
		this.name = name;
	}

	@Override
	public String toString() {
		return "Common [id=" + id + ", name=" + name + "]";
	}
	

}
