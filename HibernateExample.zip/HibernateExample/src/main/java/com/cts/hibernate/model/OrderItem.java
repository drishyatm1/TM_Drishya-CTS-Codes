package com.cts.hibernate.model;

import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

import org.hibernate.annotations.NamedQuery;

@Entity
@Table(name="order_item")
//@NamedQuery(name = "retrieveall", query = "FROM OrderItem")
public class OrderItem implements Serializable{
	
	@Id
	private int id;
	@Column(name="order_id")
	private int orderId;
	@Column(name="product_id")
	private int productId;
	@Column(name="product_count")
	private int productCount;
	@Column(name="buying_price")
	private float buyingPrice;
	
	public OrderItem() {
		
	}

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public int getOrderId() {
		return orderId;
	}

	public void setOrderId(int orderId) {
		this.orderId = orderId;
	}

	public int getProductId() {
		return productId;
	}

	public void setProductId(int productId) {
		this.productId = productId;
	}

	public int getProductCount() {
		return productCount;
	}

	public void setProductCount(int productCount) {
		this.productCount = productCount;
	}

	public float getBuyingPrice() {
		return buyingPrice;
	}

	public void setBuyingPrice(float buyingPrice) {
		this.buyingPrice = buyingPrice;
	}
	
	
	public OrderItem(int id, int orderId,int productId, int productCount, float buyingPrice) {
		this.id=id;
		this.orderId=orderId;
		this.productId=productId;
		this.productCount=productCount;
		this.buyingPrice=buyingPrice;
		
	}
	@Override
	public String toString() {
		return "OrderItem [id=" + id + ", orderId=" + orderId + ", productId=" + productId
				+ ", productCount=" + productCount + ", buyingPrice=" + buyingPrice + "]";
	}
}
