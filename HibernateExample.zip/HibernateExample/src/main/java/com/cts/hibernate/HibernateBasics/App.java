package com.cts.hibernate.HibernateBasics;



import java.util.List;

import org.hibernate.Query;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.cfg.Configuration;

import com.cts.hibernate.model.OrderItem;

public class App {

	public static void main(String args[]) {
		
		Configuration configuration=new Configuration().configure();
		SessionFactory sf=configuration.buildSessionFactory();
		Session session=sf.openSession();
		
		
		/*
		 * OrderItem oi=new OrderItem(1003,2003,3003,5,355.4f);
		 * session.beginTransaction(); session.save(oi); session.close();
		 */
		 
		
		  Query query=session.createQuery("from OrderItem o where o.id = :id ");
		  query.setParameter("id", 1001); List<OrderItem> l=query.list();
		  System.out.println(l); session.getTransaction().commit(); session.close();
		 
		
	}
}
