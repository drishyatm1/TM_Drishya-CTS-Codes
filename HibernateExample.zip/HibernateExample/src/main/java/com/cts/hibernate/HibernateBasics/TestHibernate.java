package com.cts.hibernate.HibernateBasics;

import java.io.Serializable;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.boot.registry.StandardServiceRegistryBuilder;
import org.hibernate.cfg.Configuration;

import com.cts.hibernate.model.Employee;

public class TestHibernate {

	public static void main(String args[]) {
		
		Configuration configuration=new Configuration().configure();
		SessionFactory factory = configuration.buildSessionFactory();
        Session session = factory.openSession();
		
//        Employee emp=new Employee(1001,"Rakesh","Manager");
//		session.beginTransaction();
//		session.save(emp);
//		session.getTransaction().commit();
//		System.out.println(emp);
//		session.close();
        
        Employee e=(Employee)session.get(Employee.class,1003);
        session.beginTransaction();
        
        e.setEmpDesig("Admin");
        session.getTransaction().commit();
        session.close();
		
	}
}
