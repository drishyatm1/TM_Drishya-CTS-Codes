package com.cts.Hibernate;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.cfg.Configuration;

import com.cts.HibernateModel.Account;
import com.cts.HibernateModel.DematAccount;
import com.cts.HibernateModel.SavingsAccount;



public class Test {
	public static void main(String args[]) {
		
		Configuration configuration=new Configuration().configure();
		SessionFactory sf=configuration.buildSessionFactory();
		Session session=sf.openSession();
		
		Account acc=new Account();
		acc.setAccNumb(94896);
		acc.setName("drishya");
		
		//session.getTransaction().commit();
		//session.close();
		
		DematAccount da=new DematAccount();
		da.setAccNumb(6456);
		da.setName("anu");
		da.setShares(569);
		
		//session.getTransaction().commit();
		//session.close();
		
		SavingsAccount sa=new SavingsAccount();
		sa.setAccNumb(75698);
		sa.setName("athi");
		sa.setInterestRate(5.8f);
		
		session.beginTransaction();
		session.save(acc);
		session.save(da);
		session.save(sa);
		session.getTransaction().commit();
		session.close();
		
	}

}
