package com.cts.HibernateModel;

import javax.persistence.Entity;
import javax.persistence.PrimaryKeyJoinColumn;

@Entity
//@PrimaryKeyJoinColumn(name="account_number")
public class SavingsAccount extends Account {
	
	private float interestRate;

	public float getInterestRate() {
		return interestRate;
	}

	public void setInterestRate(float interestRate) {
		this.interestRate = interestRate;
	}

	public SavingsAccount() {
		
	}
}
