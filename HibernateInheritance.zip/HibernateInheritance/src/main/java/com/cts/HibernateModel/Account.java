package com.cts.HibernateModel;

import java.io.Serializable;

import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Inheritance;
import javax.persistence.InheritanceType;

@Entity
@Inheritance(strategy=InheritanceType.TABLE_PER_CLASS)
public class Account implements Serializable{
	@Id
	private int accNumb;
	private String name;
	
	
	
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public int getAccNumb() {
		return accNumb;
	}
	public void setAccNumb(int accNumb) {
		this.accNumb = accNumb;
	}
	
	
		
	}


